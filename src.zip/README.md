# Поиск автозапчастей

React-приложение для поиска автомобильных запчастей и аналогов по артикулу.

Пользователь вводит артикул, получает список производителей, выбирает нужного и видит предложения с ценами и наличием по складам.

### Demo
https://parts-search.vercel.app (ссылка после деплоя)

## Технологии

- React 19 + Vite 8
- Redux Toolkit + React-Redux
- Bootstrap 5
- JavaScript (без TypeScript)

## Развертывание

### Vercel (рекомендуется)

```bash
npm install -g vercel
vercel
```

Или через GitHub:
1. Прикрепите репозиторий к Vercel
2. Подтвердите конфигурацию (Vercel определит Vite проект)
3. Deploy! Ссылка будет доступна сразу

### Локальное развитие

```bash
npm install          # установить зависимости
npm run dev          # запустить dev-сервер (http://localhost:5173)
npm run build        # production-сборка в dist/
npm run preview      # показать собранную версию
```

### Тесты

```bash
npm run test
```

Все 5 unit-тестов проходят ✓

## Архитектура

```
src/
├── app/store.js                       Redux store
├── features/parts/
│   ├── partsSlice.js                  Состояние поиска, защита от устаревших ответов
│   ├── partsThunks.js                 Async actions (fetchBrands, fetchOffers)
│   └── partsSelectors.js              Селекторы
├── services/
│   └── partsApi.js                    API layer (Favorit Parts API)
├── utils/
│   ├── normalizeArticle.js            Валидация артикула
│   └── apiMode.js                     Режим работы API (real/mock)
└── components/
    ├── SearchForm.jsx                 Форма поиска с debounce
    ├── BrandList.jsx                  Список производителей
    ├── OffersTable.jsx                Таблица предложений
    ├── Loader.jsx                     Индикатор загрузки
    ├── ErrorMessage.jsx               Сообщения об ошибках
    └── EmptyState.jsx                 Пустые состояния
```

**Ключевые фичи:**
- Debounce search (400мс)
- Protection from stale responses (requestId tracking)
- Чистая архитектура (feature-slices pattern)
- Production-ready build

## API

Подключен к API Favorit Parts (http://api.favorit-parts.ru/hs/hsprice):

- `getBrands(article)` — список производителей по артикулу
- `getOffers(article, brandId)` — предложения с ценами и остатками

Ключ API: `test-api-key-00000000-0000-0000-0000-000000000000`

## Что ещё можно расширить

- Развернуть на Vercel (уже настроено через vercel.json)
- Добавить покрытие тестами > 80%
- Интеграция с реальным API (подключено)
- Конфигурация API ключа через переменные окружения VITE_*
- Интеграционные тесты (e2e)

## Требования

- Node.js 20.19+ или 22.12+
- npm 10+