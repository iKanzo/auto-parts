import {encodeURIComponent} from '../utils/encodeURIComponent';

const API_BASE_URL = '/api/hs/hsprice';

/**
 * Ошибка API с указанием кода статуса
 */
export class ApiError extends Error {
  constructor(message, status = null) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

/**
 * Получить производителей по артикулу
 */
export async function getBrands(article) {
  const urlParams = new URLSearchParams({
    number: encodeURIComponent(article),
  });
  const url = `${API_BASE_URL}?${urlParams}`;

  const response = await fetch(url);

  if (!response.ok) {
    throw new ApiError(
        `HTTP ${response.status}: Не удалось получить производителей`,
        response.status
    );
  }

  const data = await response.json();

  if (data.error) {
    throw new ApiError(data.error);
  }

  if (!data.goods || data.goods.length === 0) {
    return [];
  }

  const brands = data.goods.map(item => ({
    id: item.brand,
    name: item.brand,
  }));

  return brands;
}

/**
 * Получить предложения по артикулу и ID производителя
 */
export async function getOffers(article, brandId) {
  const urlParams = new URLSearchParams({
    number: encodeURIComponent(article),
    brand: encodeURIComponent(brandId),
    analogues: 'on',
    info: 'on',
  });
  const url = `${API_BASE_URL}?${urlParams}`;

  const response = await fetch(url);

  if (!response.ok) {
    throw new ApiError(
        `HTTP ${response.status}: Не удалось получить предложения`,
        response.status
    );
  }

  const data = await response.json();

  if (data.error) {
    throw new ApiError(data.error);
  }

  const goods = (data.goods || []).find(g => g.brand === brandId);

  if (!goods?.warehouses || goods.warehouses.length === 0) {
    return [];
  }

  const offers = goods.warehouses.map(w => ({
    id: w.id,
    brand: goods.brand,
    brandId,
    name: goods.name,
    stock: w.stock,
    price: w.price,
    warehouse: w.code,
    own: w.own,
    notRefund: w.notRefund,
  }));

  return offers;
}
